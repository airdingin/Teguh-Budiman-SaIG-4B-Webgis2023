<?php
require_once('viewhead.php');
require_once('viewheader.php');
require_once('viewnav.php');
require_once('viewcontent.php');
require_once('viewfooter.php');
